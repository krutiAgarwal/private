package com.todos.qa.testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.todos.pages.HomePage;

public class HomePageTest {

	HomePage homePage;
	public static WebDriver driver;

	@BeforeSuite
	public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32 (1)\\chromedriver.exe");
		
		
		 driver=new ChromeDriver();
//		
//	
//	
//		WebDriver driver1=new ChromeDriver();
//		driver1.
		
		driver = new ChromeDriver();

		driver.manage().deleteAllCookies();

		driver.get("https://todomvc.com/examples/react/#/)");
		homePage = new HomePage();
		String title = homePage.validatetodosHeading();
		System.out.println("the title is " + title);
		
		Select sel =new Select (homePage.getCheckBoxToComplete());
		
		
		List<WebElement> list=driver.findElements(By.id(""));
		
		
		
		
		list.get(10).click();
		
		String K="Kruti";
		
		char[] S= K.toCharArray();
				
		
		
		sel.isMultiple();
		try{

			//line of code

			}

		
		
		
			catch(NullPointerException e){



			}

		catch(Exception e){

			//line of code

			}
		
		
		
		
		
		
	}

	@Test
	public void todosFunctionality() throws InterruptedException {
		
		


 

		String taskCreated = homePage.createTask("Test1");
		Assert.assertEquals(taskCreated, "Test1");
		homePage.getCheckBoxToComplete().click();
		System.out.println("The Task is marked as completed");

		// Delete button is not working I tried and stuck here

	}

	@AfterSuite
	public void close() {
		driver.quit();
	}

}
