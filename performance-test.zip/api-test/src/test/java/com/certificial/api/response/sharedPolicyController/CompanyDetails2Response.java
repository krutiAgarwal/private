package com.certificial.api.response.sharedPolicyController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyDetails2Response {
	 	private String status;
	    private int code;
	    private String message;
	    private CompanyDetails2DTO data;
	    private String uid;
	    
	    public CompanyDetails2Response() {
	    	
	    }

	    public void setStatus(String status){
	        this.status = status;
	    }
	    public String getStatus(){
	        return this.status;
	    }
	    public void setCode(int code){
	        this.code = code;
	    }
	    public int getCode(){
	        return this.code;
	    }
	    public void setMessage(String message){
	        this.message = message;
	    }
	    public String getMessage(){
	        return this.message;
	    }
	    public void setData(CompanyDetails2DTO data){
	        this.data = data;
	    }
	    public CompanyDetails2DTO getData(){
	        return this.data;
	    }
	    public void setUid(String uid){
	        this.uid = uid;
	    }
	    public String getUid(){
	        return this.uid;
	    }
}
