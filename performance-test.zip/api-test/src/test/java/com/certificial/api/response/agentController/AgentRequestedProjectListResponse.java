package com.certificial.api.response.agentController;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentRequestedProjectListResponse {
	
	private String status;
    private int code;
    private String message;
	private List<AgentRequestedProjectListDTO> data;
    private String uid;

    public AgentRequestedProjectListResponse() {
    	
    }
    
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setCode(int code){
        this.code = code;
    }
    public int getCode(){
        return this.code;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getMessage(){
        return this.message;
    }
  
    public void setUid(String uid){
        this.uid = uid;
    }
    public String getUid(){
        return this.uid;
    }
    public List<AgentRequestedProjectListDTO> getData() {
		return data;
	}

	public void setData(List<AgentRequestedProjectListDTO> data) {
		this.data = data;
	}
}
