package com.certificial.api.test.userController;

//import static io.restassured.RestAssured.given;

import org.springframework.http.HttpStatus;
import org.testng.Assert;

import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.loginController.ResponseEn;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class UserDetailsTest extends ApiBaseTest {
	
	@Test
	public void userDetails() {
		
	Response response =
			givenAuth().
                    contentType(ContentType.JSON).
                    when().
                    get(getpathURI()+ Constants.User +"/userdetails/"+getUserId()).
                    then().
                    statusCode(HttpStatus.OK.value()).
                    and().extract().response();
  
	
    Assert.assertEquals(200, response.statusCode());  
    System.out.println(response.statusCode());
   
   ResponseEn responseEn = response.as(ResponseEn.class);
    Assert.assertTrue(responseEn.getData().getIsActive());
    logger.info(" UserDetails API");
 
    


    
	}
}
