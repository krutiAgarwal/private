package com.certificial.api.response.policyRequestController;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PendingRequestDTO {

	private List<PendingRequestDetails> requests;
    private String last_update;
    private int requester_company_id;
    private List<Integer> request_arr;
    private List<String> status_arr;
    private String compliance;
    private int requestor_comp_id;
    private String requestor_comp_name;

    public void setRequests(List<PendingRequestDetails> requests){
        this.requests = requests;
    }
    public List<PendingRequestDetails> getRequests(){
        return this.requests;
    }
    public void setlast_update(String last_update){
        this.last_update = last_update;
    }
    public String getlast_update(){
        return this.last_update;
    }
    public void setRequester_company_id(int requester_company_id){
        this.requester_company_id = requester_company_id;
    }
    public int getRequester_company_id(){
        return this.requester_company_id;
    }
    public void setRequest_arr(List<Integer> request_arr){
        this.request_arr = request_arr;
    }
    public List<Integer> getRequest_arr(){
        return this.request_arr;
    }
    public void setStatus_arr(List<String> status_arr){
        this.status_arr = status_arr;
    }
    public List<String> getStatus_arr(){
        return this.status_arr;
    }
    public void setCompliance(String compliance){
        this.compliance = compliance;
    }
    public String getCompliance(){
        return this.compliance;
    }
    public void setRequestor_comp_id(int requestor_comp_id){
        this.requestor_comp_id = requestor_comp_id;
    }
    public int getRequestor_comp_id(){
        return this.requestor_comp_id;
    }
    public void setRequestor_comp_name(String requestor_comp_name){
        this.requestor_comp_name = requestor_comp_name;
    }
    public String getRequestor_comp_name(){
        return this.requestor_comp_name;
    }

}
