package com.certificial.api.test.agentController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.agentController.AgentCompanyListResponse;
import com.certificial.api.response.policyRequestController.PendingRequestResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetDashboardCompanyListTest extends ApiBaseTest {

	 @Test(enabled = true)
	    public void GetDashboardCompanyList() {

	  Response response =
  		givenAuth().
                  contentType(ContentType.JSON).
                  when().
                  get(getpathURI()+Constants.AgentDashboard+"/companylist/"+getAgentId()).
                  then().
                  statusCode(HttpStatus.OK.value()).
                  and().extract().response();
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());
	   logger.info(" GetDashboardCompanyList API");
	
	   AgentCompanyListResponse agentCompanyListResponse = response.as(AgentCompanyListResponse.class);
	   logger.info("companyCount: "+agentCompanyListResponse.getData().get(0).getCompanies().get(0).getCompanyCount());
	   
	   String[] temp = getAgentCompanies().split(","); 
	   
	   for (int i = 0; i < temp.length; i++) {

			logger.info(agentCompanyListResponse.getData().get(0).getCompanies().get(i).getName());
			Assert.assertTrue(agentCompanyListResponse.getData().get(0).getCompanies().get(i).getName().contentEquals(temp[i]));
	   	}
	 }
}