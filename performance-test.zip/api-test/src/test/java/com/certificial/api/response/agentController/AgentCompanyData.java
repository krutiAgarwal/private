package com.certificial.api.response.agentController;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentCompanyData {
	 	private String street;
	    private String city;
	    private String state;
	    private String postalCode;
	    private int agentId;
	    private String primaryContact;
	    private int primaryContactId;
	    private String logo;
	    private String name;
	    
		private List<AgentCompaniesList> companies;

	    public void setStreet(String street){
	        this.street = street;
	    }
	    
	    public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
	    public String getStreet(){
	        return this.street;
	    }
	    public void setCity(String city){
	        this.city = city;
	    }
	    public String getCity(){
	        return this.city;
	    }
	    public void setState(String state){
	        this.state = state;
	    }
	    public String getState(){
	        return this.state;
	    }
	    public void setPostalCode(String postalCode){
	        this.postalCode = postalCode;
	    }
	    public String getPostalCode(){
	        return this.postalCode;
	    }
	    public void setAgentId(int agentId){
	        this.agentId = agentId;
	    }
	    public int getAgentId(){
	        return this.agentId;
	    }
	    public void setPrimaryContact(String primaryContact){
	        this.primaryContact = primaryContact;
	    }
	    public String getPrimaryContact(){
	        return this.primaryContact;
	    }
	    public void setPrimaryContactId(int primaryContactId){
	        this.primaryContactId = primaryContactId;
	    }
	    public int getPrimaryContactId(){
	        return this.primaryContactId;
	    }
	    public void setLogo(String logo){
	        this.logo = logo;
	    }
	    public String getLogo(){
	        return this.logo;
	    }
	    public void setCompanies(List<AgentCompaniesList> companies){
	        this.companies = companies;
	    }
	    public List<AgentCompaniesList> getCompanies(){
	        return this.companies;
	    }

}
