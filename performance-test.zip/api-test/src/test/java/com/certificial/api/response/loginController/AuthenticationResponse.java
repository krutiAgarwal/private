package com.certificial.api.response.loginController;

import java.util.ArrayList;
import java.util.List;

import com.certificial.api.response.dashboardController.CompanyDetailsDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthenticationResponse {

	private String jwt;
	private long id;
	private String firstName;
	private String lastName;
	private String role;
	private Boolean userFirstLogin;
	private Boolean userFirstTutorial;
	private Long primaryContactId;
	private Boolean isActive;
	private Boolean isSuperuser;
	private Boolean flag;
	private String message;
	private List<CompanyDetailsDTO> trackedList = new ArrayList<>();
	private List<CompanyListDTO> companies = new ArrayList<>();
	
	
	public AuthenticationResponse() {
	}

	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	public String getJwt() {
		return jwt;
	}

	public void setJwt(String jwt) {
		this.jwt = jwt;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Boolean getUserFirstLogin() {
		return userFirstLogin;
	}

	public void setUserFirstLogin(Boolean userFirstLogin) {
		this.userFirstLogin = userFirstLogin;
	}

	public Boolean getUserFirstTutorial() {
		return userFirstTutorial;
	}

	public void setUserFirstTutorial(Boolean userFirstTutorial) {
		this.userFirstTutorial = userFirstTutorial;
	}

	public Long getPrimaryContactId() {
		return primaryContactId;
	}

	public void setPrimaryContactId(Long primaryContactId) {
		this.primaryContactId = primaryContactId;
	}
	
	public Boolean getIsActive() {
		  return isActive; 
	}
	  
	public void setIsActive(Boolean isActive) {
		  this.isActive = isActive;
	}
	 
	
	public Boolean getFlag() {
		return flag;
	}

	public void setFlag(Boolean flag) {
		this.flag = flag;
	}

	public Boolean getIsSuperuser() {
		return isSuperuser;
	}

	public void setIsSuperuser(Boolean isSuperuser) {
		this.isSuperuser = isSuperuser;
	}

	
	public List<CompanyDetailsDTO> getTrackedList() { 
		  return trackedList; 
		  }
	  
	public void setTrackedList(List<CompanyDetailsDTO> trackedList) {
		  this.trackedList = trackedList; 
	  }


	public List<CompanyListDTO> getCompanies() {
		return companies;
	}


	public void setCompanies(List<CompanyListDTO> companies) {
		this.companies = companies;
	}


	
}

