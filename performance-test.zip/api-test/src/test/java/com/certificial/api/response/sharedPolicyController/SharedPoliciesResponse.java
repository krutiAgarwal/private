package com.certificial.api.response.sharedPolicyController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SharedPoliciesResponse {
	
	 	private String status;
	    private int code;
	    private String message;
	    private SharedPoliciesListDTO data;
	    private String uid;

	    public SharedPoliciesResponse() {
	    	
	    }
	    
	    public void setStatus(String status){
	        this.status = status;
	    }
	    public String getStatus(){
	        return this.status;
	    }
	    public void setCode(int code){
	        this.code = code;
	    }
	    public int getCode(){
	        return this.code;
	    }
	    public void setMessage(String message){
	        this.message = message;
	    }
	    public String getMessage(){
	        return this.message;
	    }
	    public void setData(SharedPoliciesListDTO data){
	        this.data = data;
	    }
	    public SharedPoliciesListDTO getData(){
	        return this.data;
	    }
	    public void setUid(String uid){
	        this.uid = uid;
	    }
	    public String getUid(){
	        return this.uid;
	    }

}
