package com.certificial.api.response.policyRequestController;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectResponse {
	
		private  String code;
		private  String message;
		private  String status;
		private  String uid;
		private List<ProjectDetailsDTO> data = new ArrayList<>();
		

		public ProjectResponse() {
		}
		
		

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getUid() {
			return uid;
		}

		public void setUid(String uid) {
			this.uid = uid;
		}



		public List<ProjectDetailsDTO> getData() {
			return data;
		}



		public void setData(List<ProjectDetailsDTO> data) {
			this.data = data;
		}

		

}