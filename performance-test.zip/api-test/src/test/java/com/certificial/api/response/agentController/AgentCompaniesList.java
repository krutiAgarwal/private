package com.certificial.api.response.agentController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentCompaniesList {
	
	   private int insuredCompanyId;
	    private int companyCount;
	    private String name;
	    private String street;
	    private String city;
	    private String state;
	    private String logo;
	    private String postalCode;
	    private int primaryContactId;
	    private String primaryContact;
	    private int regionId;

	    public void setInsuredCompanyId(int insuredCompanyId){
	        this.insuredCompanyId = insuredCompanyId;
	    }
	    public int getInsuredCompanyId(){
	        return this.insuredCompanyId;
	    }
	    public void setCompanyCount(int companyCount){
	        this.companyCount = companyCount;
	    }
	    public int getCompanyCount(){
	        return this.companyCount;
	    }
	    public void setName(String name){
	        this.name = name;
	    }
	    public String getName(){
	        return this.name;
	    }
	    public void setStreet(String street){
	        this.street = street;
	    }
	    public String getStreet(){
	        return this.street;
	    }
	    public void setCity(String city){
	        this.city = city;
	    }
	    public String getCity(){
	        return this.city;
	    }
	    public void setState(String state){
	        this.state = state;
	    }
	    public String getState(){
	        return this.state;
	    }
	    public void setLogo(String logo){
	        this.logo = logo;
	    }
	    public String getLogo(){
	        return this.logo;
	    }
	    public void setPostalCode(String postalCode){
	        this.postalCode = postalCode;
	    }
	    public String getPostalCode(){
	        return this.postalCode;
	    }
	    public void setPrimaryContactId(int primaryContactId){
	        this.primaryContactId = primaryContactId;
	    }
	    public int getPrimaryContactId(){
	        return this.primaryContactId;
	    }
	    public void setPrimaryContact(String primaryContact){
	        this.primaryContact = primaryContact;
	    }
	    public String getPrimaryContact(){
	        return this.primaryContact;
	    }
	    public void setRegionId(int regionId){
	        this.regionId = regionId;
	    }
	    public int getRegionId(){
	        return this.regionId;
	    }

}
