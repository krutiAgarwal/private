package com.certificial.api.response.dashboardController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyResponse {


	public PolicyDetails policiesDetails;


	public PolicyDetails getPoliciesDetails() {
		return policiesDetails;
	}

	public void setPoliciesDetails(PolicyDetails policiesDetails) {
		this.policiesDetails = policiesDetails;
	}
}

