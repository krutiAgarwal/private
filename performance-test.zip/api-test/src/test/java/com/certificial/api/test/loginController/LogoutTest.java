package com.certificial.api.test.loginController;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.loginController.ResponseEn;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;
//import static io.restassured.RestAssured.given;

public class LogoutTest extends ApiBaseTest  {
@Test	
public void logout() {
	
	
	  Response response= givenAuth().
                        contentType(ContentType.JSON).
                        when().
                        get(getpathURI()+ Constants.Logout +"/"+getUserId()+"?token="+getCurrentToken()).
                        then().
                        statusCode(HttpStatus.OK.value()).
                        and().extract().response();
        
                
        Assert.assertEquals(200, response.statusCode());
        System.out.println(response.statusCode());
        logger.info(" Logout API");
           
        ResponseEn responseEn = response.as(ResponseEn.class);
        logger.info(responseEn.getData().getMessage());    
       Assert.assertEquals("You have successfully logged out.", responseEn.getData().getMessage() );
       
       
       
    }
    
} 
    



