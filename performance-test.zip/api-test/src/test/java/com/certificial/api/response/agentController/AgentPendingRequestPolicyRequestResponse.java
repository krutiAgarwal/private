package com.certificial.api.response.agentController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentPendingRequestPolicyRequestResponse {
	
	 	private String status;
	    private int code;
	    private String message;
	    private AgentPendingRequestPolicies data;
	    private String uid;

	    public AgentPendingRequestPolicyRequestResponse() {
	    	
	    }
	    
	    public void setStatus(String status){
	        this.status = status;
	    }
	    public String getStatus(){
	        return this.status;
	    }
	    public void setCode(int code){
	        this.code = code;
	    }
	    public int getCode(){
	        return this.code;
	    }
	    public void setMessage(String message){
	        this.message = message;
	    }
	    public String getMessage(){
	        return this.message;
	    }
	    public void setData(AgentPendingRequestPolicies data){
	        this.data = data;
	    }
	    public AgentPendingRequestPolicies getData(){
	        return this.data;
	    }
	    public void setUid(String uid){
	        this.uid = uid;
	    }
	    public String getUid(){
	        return this.uid;
	    }

}
