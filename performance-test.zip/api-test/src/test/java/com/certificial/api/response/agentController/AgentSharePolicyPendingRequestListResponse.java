package com.certificial.api.response.agentController;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentSharePolicyPendingRequestListResponse {
	
	private String status;
    private int code;
    private String message;
    private List<SharePolicyPendingRequestListDTO> data;
    private String uid;

    public AgentSharePolicyPendingRequestListResponse() {
    	
    }
    
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setCode(int code){
        this.code = code;
    }
    public int getCode(){
        return this.code;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getMessage(){
        return this.message;
    }
  
    public List<SharePolicyPendingRequestListDTO> getData() {
		return data;
	}
	public void setData(List<SharePolicyPendingRequestListDTO> data) {
		this.data = data;
	}
	public void setUid(String uid){
        this.uid = uid;
    }
    public String getUid(){
        return this.uid;
    }

}
