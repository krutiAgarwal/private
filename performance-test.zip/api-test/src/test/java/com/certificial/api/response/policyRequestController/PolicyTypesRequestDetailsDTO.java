package com.certificial.api.response.policyRequestController;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyTypesRequestDetailsDTO {
	
	private int policyrequestId;
    private int issuerId;
    private String rejectionReason;
    private String status;
    private int requesterCompanyId;
    private int requesterUserId;
    private String usedTemplateId;
    private String usedTemplateName;
    private String instructionText;
    private String requiredRating;
    private String lastUpdatedOn;
    private int regionId;
    private String regionName;
    private String regionCurrency;
    private String currencySymbol;
    private boolean disableCertUploadButton;

    private List<PolicyTypes> policyTypes;

    public void setPolicyrequestId(int policyrequestId){
        this.policyrequestId = policyrequestId;
    }
    public int getPolicyrequestId(){
        return this.policyrequestId;
    }
    public void setIssuerId(int issuerId){
        this.issuerId = issuerId;
    }
    public int getIssuerId(){
        return this.issuerId;
    }
    public void setRejectionReason(String rejectionReason){
        this.rejectionReason = rejectionReason;
    }
    public String getRejectionReason(){
        return this.rejectionReason;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setRequesterCompanyId(int requesterCompanyId){
        this.requesterCompanyId = requesterCompanyId;
    }
    public int getRequesterCompanyId(){
        return this.requesterCompanyId;
    }
    public void setRequesterUserId(int requesterUserId){
        this.requesterUserId = requesterUserId;
    }
    public int getRequesterUserId(){
        return this.requesterUserId;
    }
    public void setUsedTemplateId(String usedTemplateId){
        this.usedTemplateId = usedTemplateId;
    }
    public String getUsedTemplateId(){
        return this.usedTemplateId;
    }
    public void setUsedTemplateName(String usedTemplateName){
        this.usedTemplateName = usedTemplateName;
    }
    public String getUsedTemplateName(){
        return this.usedTemplateName;
    }
    public void setInstructionText(String instructionText){
        this.instructionText = instructionText;
    }
    public String getInstructionText(){
        return this.instructionText;
    }
    public void setRequiredRating(String requiredRating){
        this.requiredRating = requiredRating;
    }
    public String getRequiredRating(){
        return this.requiredRating;
    }
    public void setLastUpdatedOn(String lastUpdatedOn){
        this.lastUpdatedOn = lastUpdatedOn;
    }
    public String getLastUpdatedOn(){
        return this.lastUpdatedOn;
    }
    public void setRegionId(int regionId){
        this.regionId = regionId;
    }
    public int getRegionId(){
        return this.regionId;
    }
    public void setRegionName(String regionName){
        this.regionName = regionName;
    }
    public String getRegionName(){
        return this.regionName;
    }
    public void setRegionCurrency(String regionCurrency){
        this.regionCurrency = regionCurrency;
    }
    public String getRegionCurrency(){
        return this.regionCurrency;
    }
    public void setCurrencySymbol(String currencySymbol){
        this.currencySymbol = currencySymbol;
    }
    public String getCurrencySymbol(){
        return this.currencySymbol;
    }
    public void setDisableCertUploadButton(boolean disableCertUploadButton){
        this.disableCertUploadButton = disableCertUploadButton;
    }
    public boolean getDisableCertUploadButton(){
        return this.disableCertUploadButton;
    }
    public void setPolicyTypes(List<PolicyTypes> policyTypes){
        this.policyTypes = policyTypes;
    }
    public List<PolicyTypes> getPolicyTypes(){
        return this.policyTypes;
    }

}
