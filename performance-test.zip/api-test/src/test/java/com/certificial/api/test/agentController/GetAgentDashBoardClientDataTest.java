package com.certificial.api.test.agentController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.agentController.AgentDashBoardClientDataResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetAgentDashBoardClientDataTest extends ApiBaseTest {
	
	@Test(enabled = true)
	    public   void  GetAgentDashBoardClientData() {

	  Response response =
   		givenAuth().
                   contentType(ContentType.JSON).
                   when().
                   get(getpathURI()+Constants.AgentDashboard+"/1/"+getAgentId()+"/"+getAgentCompanyId()).
                   then().
                   statusCode(HttpStatus.OK.value()).
                   and().extract().response();
	  
	  //System.out.println(response.asString());
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());	   
	   logger.info(" GetAgent Dashboard client Data  API");
	   
	   System.out.println(response.asString());
	   AgentDashBoardClientDataResponse agentDashBoardClientData = response
				.as(AgentDashBoardClientDataResponse.class);
	   
	   Assert.assertTrue(agentDashBoardClientData.getData().get(1).getPolicyType().equalsIgnoreCase(getAgentPolicyType()));
	
//Extarcting Agency ID from the response
	   agentDashBoardClientData.getData().get(1).setPolicyAgencyId(agentDashBoardClientData.getData().get(1).getPolicyAgencyId());
	   
	   String  policyAgencyId=agentDashBoardClientData.getData().get(1).getPolicyAgencyId();
	   
	   logger.info("policyAgencyId:" +policyAgencyId);
	   
	
	  
	 }
}

