package com.certificial.api.test.loginController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.loginController.ResponseEn;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class MaintenanceTest  extends ApiBaseTest {

	@Test
	public void maintenance() {
		
	Response response =
			givenAuth().
                    contentType(ContentType.JSON).
                    when().
                    get(getpathURI()+ Constants.Maintenance).
                    then().
                    statusCode(HttpStatus.OK.value()).
                    and().extract().response();
  
	
    Assert.assertEquals(200, response.statusCode());
    System.out.println(response.statusCode());
    logger.info(" Maintenance API");
    ResponseEn responseEn = response.as(ResponseEn.class);
   // System.out.println(responseEn.getData().getFlag());
    //Assert.assertFalse(responseEn.getData().getFlag());
}
}