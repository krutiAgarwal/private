package com.certificial.api.config;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.certificial.api.response.loginController.ResponseEn;
import com.certificial.api.test.loginController.LoginRequest;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.restassured.RestAssured;
import io.restassured.config.JsonConfig;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.parsing.Parser;
import io.restassured.path.json.config.JsonPathConfig;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

@Test(singleThreaded = true)
@ContextConfiguration(classes = { ConfigTest.class })
public abstract class ApiBaseTest extends AbstractTestNGSpringContextTests {

	protected static Logger logger = LoggerFactory.getLogger(ApiBaseTest.class);

	@Value("${api.server.pathURI}")
	private String pathURI;
	@Value("${api.server.port}")
	private int port;
	@Value("${api.server.protocol}")
	private String protocol;
	@Value("${api.server.baseIp}")
	private String baseIp;
	@Value("${jwt.authentication.path}")
	private String authenticationURI;
	@Value("${api.server.username}")
	private String username = "xormdrequester01@gmail.com";
	@Value("${api.server.password}")
	private String password = "";
	@Value("${api.server.company}")
	private String company;

	@Value("${api.data.userId}")
	private String userId;
	@Value("${api.data.projectId}")
	private String projectId;
	@Value("${api.data.sharedId}")
	private String sharedId;
	@Value("${api.data.isReviewed}")
	private Boolean isReviewed;
	@Value("${api.data.companyId}")
	private String companyId;
	@Value("${api.data.policyNumber}")
	private String policyNumber;
	@Value("${api.data.companyStatus}")
	private String companyStatus;
	@Value("${api.data.query}")
	private String query;
	@Value("${api.data.companies}")
	private String companies;
	@Value("${api.data.sharedCompanyId}")
	private String sharedCompanyId;
	@Value("${api.data.projectsName}")
	private String projectsName;
	@Value("${api.data.requestedPolicies}")
	private String requestedPolicies;
	@Value("${api.data.requestId}")
	private int requestId;
	@Value("${api.data.requestedPolicyTypes}")
	private String requestedPolicyTypes;
	@Value("${api.data.requestID}")
	private int requestID;
	@Value("${api.data.pendingRequestedPolicies}")
	private String pendingRequestedPolicies;
	@Value("${api.data.requestPolicyStatus}")
	private String requestPolicyStatus;
	@Value("${api.data.flag}")
	private String flag;
	@Value("${api.data.sharedPolicies}")
	private String sharedPolicies;
	@Value("${api.data.agentId}")
	private int agentId;
	@Value("${api.data.agentCompanies}")
	private String agentCompanies;

	@Value("${api.data.agentCompanyId}")
	private String agentCompanyId;

	@Value("${api.data.agentPolicyType}")
	private String agentPolicyType;

	
	@Value("${api.data.agentPolicyId}")
	private String agentPolicyId;
	
	@Value("${api.data.agentOpenRequestCount}")
	private String agentOpenRequestCount;
	
	@Value("${api.data.insuredCompanyId}")
	private int insuredCompanyId ;
	
	@Value("${api.data.requesterCompanyId}")
	private int requesterCompanyId ;
	
	@Value("${api.data.requestedProject}")
	private String requestedProject ;
	
	@Value("${api.data.agentpolicyRequestId}")
	private int agentpolicyRequestId  ;
	
	@Value("${api.data.agentShareId}")
	private int agentShareId  ;
	
	@Value("${api.data.shareProject}")
	private String shareProject  ;

	@Value("${api.data.sharedPolicyId}")
	private int sharedPolicyId;
	
	@Value("${api.data.sharedpolicyNumber}")
	private String sharedpolicyNumber;
	
	@Value("${api.data.sharePolicyFromCompany}")
	private String sharePolicyFromCompany;
	
	@Value("${api.data.sharePolicyToCompany}")
	private String sharePolicyToCompany;
	
	@Value("${api.data.policyIDs}")
	private List<String> policyIDs;
	@Value("${api.data.coiSharedId}")
	private String coiSharedId;
	
	@Value("${api.data.coiProjecId}")
	private String coiProjecId;
	


	private String resolvedIp;
	private static String currentToken = "NA";
	private String currentNoAccessToken = "NA";

	protected static void assertBigDecimalEquals(BigDecimal expected, BigDecimal actual) {
		Assert.assertEquals(expected.compareTo(actual), 0,
				"expected : " + expected.toPlainString() + " actual : " + actual.toPlainString());
	}

	public SoftAssert sAssert;

	@BeforeClass
	public void setUp() {
		// RestAssured.port = this.port;
		RestAssured.baseURI = this.protocol + this.baseIp;
		RestAssured.defaultParser = Parser.JSON;
		RestAssured.config = RestAssured.config()
				.jsonConfig(new JsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.BIG_DECIMAL));
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();

		logger.debug("PORT : " + RestAssured.port + " BASE-URI : " + RestAssured.baseURI);
		this.resolvedIp = resolvedIPfromBaseIP();
		logger.debug("Resolved Ip : " + resolvedIp);

		requestToken();
		sAssert = new SoftAssert();
	}

	protected String getResolvedIp() {
		return resolvedIp;
	}

	private String resolvedIPfromBaseIP() {
		InetAddress address = null;
		try {
			address = InetAddress.getByName(this.baseIp);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return address != null ? address.getHostAddress() : null;
	}

	@AfterClass
	public void assertAll() {
		sAssert.assertAll();
	}

	protected String getAuthenticationURI() {
		return authenticationURI;
	}

	protected String getpathURI() {
		return pathURI;
	}

	public String getCompany() {
		return company;
	}

	public String getProjectId() {
		return projectId;
	}

	
	public String getAgentPolicyType() {
		return agentPolicyType;
	}

	public String getAgentCompanyId() {
		return agentCompanyId;
	}
	public String getSharedId() {
		return sharedId;
	}

	public Boolean getIsReviewed() {
		return isReviewed;
	}

	public String getCompanyId() {
		return companyId;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public String getCompanyStatus() {
		return companyStatus;
	}

	public String getQuery() {
		return query;
	}

	public String getCompanies() {
		return companies;
	}

	public String getSharedCompanyId() {
		return sharedCompanyId;
	}

	public String getUserId() {
		return userId;
	}

	public String getProjectsName() {
		return projectsName;
	}

	public String getRequestedPolicies() {
		return requestedPolicies;
	}

	public int getRequestId() {
		return requestId;
	}

	public int getRequestID() {
		return requestID;
	}

	public String getRequestPolicyStatus() {
		return requestPolicyStatus;
	}

	public String getFlag() {
		return flag;
	}

	public String getSharedPolicies() {
		return sharedPolicies;
	}

	public String getPendingRequestedPolicies() {
		return pendingRequestedPolicies;
	}

	public String getRequestedPolicyTypes() {
		return requestedPolicyTypes;
	}

	public int getAgentId() {
		return agentId;
	}

	public String getAgentCompanies() {
		return agentCompanies;
	}


	public String getAgentOpenRequestCount() {
		return agentOpenRequestCount;
	}

	public int getInsuredCompanyId() {
		return insuredCompanyId;
	}

	public int getRequesterCompanyId() {
		return requesterCompanyId;
	}

	public String getRequestedProject() {
		return requestedProject;
	}

	
	public int getAgentpolicyRequestId() {
		return agentpolicyRequestId;
	}

	public int getAgentShareId() {
		return agentShareId;
	}
	
	public String getShareProject() {
		return shareProject;
	}

	public List<String> getPolicyIDs() {
		return policyIDs;
	}
	
	public String getCoiSharedId() {
		return coiSharedId;
	}


	public String getCoiProjecId() {
		return coiProjecId;
	}


	
	public String getAgentPolicyId() {
		return agentPolicyId;
	}

	
	public int getSharedPolicyId() {
		return sharedPolicyId;
	}

	
	public String getSharePolicyFromCompany() {
		return sharePolicyFromCompany;
	}

	public String getSharePolicyToCompany() {
		return sharePolicyToCompany;
	}

	public String getSharedpolicyNumber() {
		return sharedpolicyNumber;
	}

	protected String getCurrentToken() {
		return currentToken;
	}

	protected void setCurrentToken(String currentToken) {
		this.currentToken = currentToken;
	}

	protected String getCurrentNoAccessToken() {
		return currentNoAccessToken;
	}

	protected void setCurrentNoAccessToken(String currentNoAccessToken) {
		this.currentNoAccessToken = currentNoAccessToken;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	protected void requestToken() {
		logger.debug("current JWT token :" + currentToken);

		final String holdToken = currentToken;

		LoginRequest loginRequest = new LoginRequest();
		loginRequest.setUsername(username);
		loginRequest.setPassword(password);

		logger.debug("User :" + username);
		logger.debug("Pass :" + password);
		logger.debug("Post URI :" + authenticationURI);
		logger.debug("request new JWT token.");
		ExtractableResponse response = given().contentType(ContentType.JSON).body(loginRequest).when()
				.post(authenticationURI).then().extract();

		if (response.response().getStatusCode() == HttpStatus.OK.value()) {
			logger.debug("request new JWT token success");

			ResponseEn jwtResponseEn = response.as(ResponseEn.class);
			this.currentToken = jwtResponseEn.getData().getJwt();

		} else {
			this.currentToken = holdToken;
			logger.debug("request new JWT token failed: " + response.body().toString());
		}

		logger.debug("result JWT token " + currentToken);
	}

	protected RequestSpecification givenAuth() {
		logger.debug("Authorization - Bearer " + currentToken);
		return given().contentType(ContentType.JSON).header(new Header("Authorization", "Bearer " + currentToken));
	}

	protected RequestSpecification givenAuthNoAccess() {
		logger.debug("Authorization - Bearer " + currentNoAccessToken);
		return given().contentType(ContentType.JSON)
				.header(new Header("Authorization", "Bearer " + currentNoAccessToken));
	}

	public static JsonObject convertFileToJSON(String fileName) {
		// Read from File to String
		File filepath = new File(System.getProperty("user.dir") + "/src/test/resources/" + fileName);
		JsonObject jsonObject = new JsonObject();
		try {
			FileReader file = new FileReader(filepath);
			JsonParser parser = new JsonParser();
			JsonElement jsonElement = parser.parse(new FileReader(filepath));
			jsonObject = jsonElement.getAsJsonObject();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return jsonObject;
	}

	protected static String updateJsonResponse(String getCustomerResponse, String key, String value) {
		JSONObject json;
		try {
			json = new JSONObject(getCustomerResponse);
			json.put(key, value);
			return json.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	protected static String updateResponse(String response, String operation, String key, Object value) {
		JSONObject json;
		try {
			json = new JSONObject(response);
			switch (operation.toLowerCase().trim()) {
			case "add":
				json.put(key, value);
				break;

			case "remove":
				json.remove(key);
				break;
			}
			return json.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return "error in update Response";
		}
	}

	protected static JSONObject updateJson(Response response) {

		JSONObject json;
		try {
			json = new JSONObject(response.prettyPrint());
			JSONArray arr = new JSONArray(response.jsonPath().getList("lines").toArray());
			arr.put(response.jsonPath().getList("lines"));
			json.put("lines", arr);
			return json;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Response get(String url) {
		Response getResponse = givenAuth().when().get(url).then().assertThat().extract().response();
		return getResponse;
	}

	public Response post(String endPointUrl, String body) {
		Response postResponse = givenAuth().when().contentType("application/json").body(body).post(endPointUrl).then()
				.assertThat().extract().response();
		return postResponse;
	}

	public Response put(String endPointUrl, String reqBody) {
		Response putResponse = givenAuth().when().contentType("application/json").body(reqBody).put(endPointUrl).then()
				.assertThat().extract().response();
		return putResponse;
	}

	public Response delete(String endPointUrl) {
		Response deleteResponse = givenAuth().when().delete(endPointUrl).then().assertThat().extract().response();
		return deleteResponse;
	}

	public int randomNumber() {
		Random rnd = new Random();
		int n = 100000 + rnd.nextInt(900000);
		return n;
	}

}
