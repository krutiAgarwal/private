package com.certificial.api.response.agentController;

import java.util.List;

import com.certificial.api.response.policyRequestController.CertHolder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentDashBoardClientDataDTO {

	
	
private String policyType;

private String policyAgencyId;

public String getPolicyType() {
	return policyType;
}

public void setPolicyType(String policyType) {
	this.policyType = policyType;
}

public String getPolicyAgencyId() {
	return policyAgencyId;
}

public void setPolicyAgencyId(String policyAgencyId) {
	this.policyAgencyId = policyAgencyId;
}


	

	
	
	

    
}
