package com.certificial.api.response.policyRequestController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectDetailsDTO {
			
			    private int id;
			    private String name;
			    private int shareId;
			    private String requestId;
			    private String flag;
			    private String regionCurrency;
			    private int regionId;
			    private String regionName;
			    private int tempalteId;
			    //private Boolean default;	
			    
			   public ProjectDetailsDTO() {
				   
			   }

			    public void setId(int id){
			        this.id = id;
			    }
			    public int getId(){
			        return this.id;
			    }
			    
			    public void setName(String name){
			        this.name = name;
			    }
			    public String getName(){
			        return this.name;
			    }
			    
			    public void setShareId(int shareId){
			        this.shareId = shareId;
			    }
			    public int getShareId(){
			        return this.shareId;
			    }
			    
			    public void setRequestId(String requestId){
			        this.requestId = requestId;
			    }
			    public String getRequestId(){
			        return this.requestId;
			    }
			    
			    public void setFlag(String flag){
			        this.flag = flag;
			    }
			    public String getFlag(){
			        return this.flag;
			    }
			    
			    public void setRegionCurrency(String regionCurrency){
			        this.regionCurrency = regionCurrency;
			    }
			    public String getRegionCurrency(){
			        return this.regionCurrency;
			    }
			    
			    public void setRegionId(int regionId){
			        this.regionId = regionId;
			    }
			    public int getRegionId(){
			        return this.regionId;
			    }
			    
			    public void setRegionName(String regionName){
			        this.regionName = regionName;
			    }
			    public String getRegionName(){
			        return this.regionName;
			    }
			    
			    public void setTempalteId(int tempalteId){
			        this.tempalteId = tempalteId;
			    }
			    public int getTempalteId(){
			        return this.tempalteId;
			    }
			 
				/*
				 * public void setDefault(Boolean default){ this.default = default; } public
				 * boolean getDefault(){ return this.default; }
				 */
			   
}
