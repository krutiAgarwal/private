package com.certificial.api.response.agentController;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentPendingRequestPolicies {
	
	private List<AgentPendingRequestPoliciesDTO> policies;

    public void setPolicies(List<AgentPendingRequestPoliciesDTO> policies){
        this.policies = policies;
    }
    public List<AgentPendingRequestPoliciesDTO> getPolicies(){
        return this.policies;
    }

}
