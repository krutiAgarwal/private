package com.certificial.api.test.sharedPolicyController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.sharedPolicyController.CompanyDetails2Response;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetCompanyDetails2Test extends ApiBaseTest {

	@Test(enabled = true)
    public void GetCompanyDetails2() {
		GetCompanyDetails2Request companyDetails2Request = new GetCompanyDetails2Request();
		companyDetails2Request.setCompanyId(getCompanyId());
		companyDetails2Request.setFlag(getFlag());;
		companyDetails2Request.setProjectId(getProjectId());
		companyDetails2Request.setShareId(getSharedId());
	
		Response response =
				givenAuth().
                  contentType(ContentType.JSON).
                  body(companyDetails2Request).
                  when().
                  post(getpathURI()+ Constants.SharedPolicy+"/company/details2").
                  then().
                  statusCode(HttpStatus.OK.value()).
                  and().extract().response();

		Assert.assertEquals(200, response.statusCode());
		System.out.println(response.statusCode());
		logger.info(" GetCompanyDetails2 API");

		CompanyDetails2Response companyDetails2Response = response.as(CompanyDetails2Response.class);
		logger.info(companyDetails2Response.getData().getName());	
		
		Assert.assertTrue(companyDetails2Response.getData().getName().contentEquals(getCompany()));
		Assert.assertEquals(getFlag(), companyDetails2Response.getData().getFlag());
}
}