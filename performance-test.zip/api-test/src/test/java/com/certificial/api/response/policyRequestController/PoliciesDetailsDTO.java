package com.certificial.api.response.policyRequestController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PoliciesDetailsDTO {

	
	
	private String policyId;
	private String shareId;
	private String templateName;
	private String verificationStatus;
	private String policyNumber;
	private Boolean isCrossCountry;
	private String userId;
	private String policyTypeId;
	private String companyId;
	private String insurerId;
	private String insurerName;
	private String insurerNaic;
	private String effectiveFrom;
	private String effectiveTo;
	private String responsible_agency_id;
	private String policyType;
	private String policytype;
	//private List<CertDTO> certList;
	
	public String getPolicytype() {
		return policytype;
	}

	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}

	public PoliciesDetailsDTO(){
		
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getShareId() {
		return shareId;
	}

	public void setShareId(String shareId) {
		this.shareId = shareId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getVerificationStatus() {
		return verificationStatus;
	}

	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Boolean getIsCrossCountry() {
		return isCrossCountry;
	}

	public void setIsCrossCountry(Boolean isCrossCountry) {
		this.isCrossCountry = isCrossCountry;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPolicyTypeId() {
		return policyTypeId;
	}

	public void setPolicyTypeId(String policyTypeId) {
		this.policyTypeId = policyTypeId;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public String getInsurerId() {
		return insurerId;
	}

	public void setInsurerId(String insurerId) {
		this.insurerId = insurerId;
	}

	public String getInsurerName() {
		return insurerName;
	}

	public void setInsurerName(String insurerName) {
		this.insurerName = insurerName;
	}

	public String getInsurerNaic() {
		return insurerNaic;
	}

	public void setInsurerNaic(String insurerNaic) {
		this.insurerNaic = insurerNaic;
	}

	public String getEffectiveFrom() {
		return effectiveFrom;
	}

	public void setEffectiveFrom(String effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}

	public String getEffectiveTo() {
		return effectiveTo;
	}

	public void setEffectiveTo(String effectiveTo) {
		this.effectiveTo = effectiveTo;
	}

	public String getResponsible_agency_id() {
		return responsible_agency_id;
	}

	public void setResponsible_agency_id(String responsible_agency_id) {
		this.responsible_agency_id = responsible_agency_id;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	
	
}
