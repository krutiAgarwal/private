package com.certificial.api.test.dashboardController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.dashboardController.CompanyResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetRequesterDashboardCompanyStatusTest  extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void CompanyStatus() {
		 
	        Response response =
	        		givenAuth().
	                        contentType(ContentType.JSON).
	                        when().
	                        get(getpathURI()+Constants.Dashboard+"/getCompanyStatus?polId=&statusFilter="+getCompanyStatus()+"&companyId="+getCompanyId()+"&projectId="+getProjectId()+"&userId="+getUserId()).
	                        then().
	                        statusCode(HttpStatus.OK.value()).
	                        and().extract().response();

	        Assert.assertEquals(200, response.statusCode());
	        System.out.println(response.statusCode());
	        logger.info(" GetRequesterDashboardCompanyStatus API");
	        CompanyResponse compResp = response.as(CompanyResponse.class);
	        logger.info(compResp.getData().toString());
		    Assert.assertEquals(getCompanyStatus(), compResp.getData().toString());

}
}