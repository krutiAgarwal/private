package com.certificial.api.response.agentController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentPendingRequestPoliciesDTO {
	
	private int policyId;
    private String policyType;
    private String policyNumber;
    private String lastVerificationDate;
    private String verificationStatus;
    private String status;

    public void setPolicyId(int policyId){
        this.policyId = policyId;
    }
    public int getPolicyId(){
        return this.policyId;
    }
    public void setPolicyType(String policyType){
        this.policyType = policyType;
    }
    public String getPolicyType(){
        return this.policyType;
    }
    public void setPolicyNumber(String policyNumber){
        this.policyNumber = policyNumber;
    }
    public String getPolicyNumber(){
        return this.policyNumber;
    }
    public void setLastVerificationDate(String lastVerificationDate){
        this.lastVerificationDate = lastVerificationDate;
    }
    public String getLastVerificationDate(){
        return this.lastVerificationDate;
    }
    public void setVerificationStatus(String verificationStatus){
        this.verificationStatus = verificationStatus;
    }
    public String getVerificationStatus(){
        return this.verificationStatus;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }

}
