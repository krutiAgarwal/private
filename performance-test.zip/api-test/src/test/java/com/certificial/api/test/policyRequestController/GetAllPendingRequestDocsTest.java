package com.certificial.api.test.policyRequestController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetAllPendingRequestDocsTest extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void GetAllPendingRequestDocs() {

	
	  Response response =
   		givenAuth().
                   contentType(ContentType.JSON).
                   when().
                   get(getpathURI()+ Constants.PolicyRequest+"/pendinglist/docs/"+getUserId()).
                   then().
                   statusCode(HttpStatus.OK.value()).
                   and().extract().response();
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());
	  
	 }
}
