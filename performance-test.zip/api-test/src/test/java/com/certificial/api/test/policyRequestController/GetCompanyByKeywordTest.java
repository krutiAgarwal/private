package com.certificial.api.test.policyRequestController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.loginController.ResponseEn;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetCompanyByKeywordTest extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void GetcompanyByKeyword() {
	    
	        Response response =
	        		givenAuth().
	                        contentType(ContentType.JSON).
	                        when().
	                        get(getpathURI()+ Constants.PolicyRequest +"/company/byemail?query="+getQuery()).
	                        then().
	                        statusCode(HttpStatus.OK.value()).
	                        and().extract().response();

	        Assert.assertEquals(200, response.statusCode());
	        System.out.println(response.statusCode());
	        logger.info(" GetCompanyByKeyword API");
	        
	        ResponseEn responseEn = response.as(ResponseEn.class);
	        Assert.assertEquals("Company found with the provided email address.", responseEn.getData().getMessage().toString());

}
	 
}
