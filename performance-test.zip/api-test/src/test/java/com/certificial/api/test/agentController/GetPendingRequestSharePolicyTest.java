package com.certificial.api.test.agentController;

import static org.testng.Assert.assertTrue;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.agentController.AgentPendingRequestPolicyRequestResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetPendingRequestSharePolicyTest extends ApiBaseTest {

	 @Test(enabled = true)
	    public void GetPendingRequestSharePolicy() {

	  Response response =
		givenAuth().
         contentType(ContentType.JSON).
         when().
         get(getpathURI()+ Constants.AgentPendingRequest+ "/sharepolicy/"+getAgentId()+"/"+getSharedPolicyId()).
         then().
         statusCode(HttpStatus.OK.value()).
         and().extract().response();
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());
	   logger.info(" GetPendingRequestSharePolicy API");
	
	   AgentPendingRequestPolicyRequestResponse agentPendingRequestPolicyRequestResp = response.as(AgentPendingRequestPolicyRequestResponse.class);
	   logger.info(agentPendingRequestPolicyRequestResp.getData().getPolicies().get(0).getPolicyNumber());
	   assertTrue(agentPendingRequestPolicyRequestResp.getData().getPolicies().get(0).getPolicyNumber().contentEquals(getSharedpolicyNumber()));
}
}