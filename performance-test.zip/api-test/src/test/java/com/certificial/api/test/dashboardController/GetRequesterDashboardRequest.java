package com.certificial.api.test.dashboardController;

import java.util.ArrayList;
import java.util.List;

import com.certificial.api.response.dashboardController.CompanyDetailsDTO;

public class GetRequesterDashboardRequest {

	private String userId;
	private int size;
	private int page;	
	private String name ;
	private Boolean isReviewed;
	private List<Integer> companyRecordFilter;
	private List<Integer> daysExpiredFilter;
	private List<Integer> endorsementFilter;
	private List<Integer> statusFilter;
	private List<CompanyDetailsDTO> trackedList = new ArrayList<>();
	 
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Boolean getIsReviewed() {
		return isReviewed;
	}
	public void setIsReviewed(Boolean isReviewed) {
		this.isReviewed = isReviewed;
	}
	public List<Integer> getCompanyRecordFilter() {
		return companyRecordFilter;
	}
	public void setCompanyRecordFilter(List<Integer> companyRecordFilter) {
		this.companyRecordFilter = companyRecordFilter;
	}
	public List<Integer> getDaysExpiredFilter() {
		return daysExpiredFilter;
	}
	public void setDaysExpiredFilter(List<Integer> daysExpiredFilter) {
		this.daysExpiredFilter = daysExpiredFilter;
	}
	public List<Integer> getEndorsementFilter() {
		return endorsementFilter;
	}
	public void setEndorsementFilter(List<Integer> endorsementFilter) {
		this.endorsementFilter = endorsementFilter;
	}
	public List<Integer> getStatusFilter() {
		return statusFilter;
	}
	public void setStatusFilter(List<Integer> statusFilter) {
		this.statusFilter = statusFilter;
	}
	public List<CompanyDetailsDTO> getTrackedList() {
		return trackedList;
	}
	public void setTrackedList(List<CompanyDetailsDTO> trackedList) {
		this.trackedList = trackedList;
	}
	
	
}
