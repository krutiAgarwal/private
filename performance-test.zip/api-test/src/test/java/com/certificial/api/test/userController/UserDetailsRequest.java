package com.certificial.api.test.userController;

public class UserDetailsRequest {

	public String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}
