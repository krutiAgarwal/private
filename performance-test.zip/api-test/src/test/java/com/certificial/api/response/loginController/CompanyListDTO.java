package com.certificial.api.response.loginController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyListDTO {
	
	public CompanyListDTO() {
		
	}
	
	private int id;
    private String name;
    private String address1;
    private String address2;
    private String city;
    private String postCode;
    private String naic;
    private String type;
    private String primaryContactId;
    private String primaryContact;
    private String state;
    private String logo;
    private String source;
    private String flag;
    private int size;
    private String regionId;
    private String regionName;
    private String certHolder;
    
    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setAddress1(String address1){
        this.address1 = address1;
    }
    public String getAddress1(){
        return this.address1;
    }
    public void setAddress2(String address2){
        this.address2 = address2;
    }
    public String getAddress2(){
        return this.address2;
    }
    public void setCity(String city){
        this.city = city;
    }
    public String getCity(){
        return this.city;
    }
    public void setPostCode(String postCode){
        this.postCode = postCode;
    }
    public String getPostCode(){
        return this.postCode;
    }
    public void setNaic(String naic){
        this.naic = naic;
    }
    public String getNaic(){
        return this.naic;
    }
    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return this.type;
    }
    public void setPrimaryContactId(String primaryContactId){
        this.primaryContactId = primaryContactId;
    }
    public String getPrimaryContactId(){
        return this.primaryContactId;
    }
    public void setPrimaryContact(String primaryContact){
        this.primaryContact = primaryContact;
    }
    public String getPrimaryContact(){
        return this.primaryContact;
    }
    public void setState(String state){
        this.state = state;
    }
    public String getState(){
        return this.state;
    }
    public void setLogo(String logo){
        this.logo = logo;
    }
    public String getLogo(){
        return this.logo;
    }
    public void setSource(String source){
        this.source = source;
    }
    public String getSource(){
        return this.source;
    }
    public void setFlag(String flag){
        this.flag = flag;
    }
    public String getFlag(){
        return this.flag;
    }
    public void setSize(int size){
        this.size = size;
    }
    public int getSize(){
        return this.size;
    }
    public void setRegionId(String regionId){
        this.regionId = regionId;
    }
    public String getRegionId(){
        return this.regionId;
    }
    public void setRegionName(String regionName){
        this.regionName = regionName;
    }
    public String getRegionName(){
        return this.regionName;
    }
    public void setCertHolder(String certHolder){
        this.certHolder = certHolder;
    }
    public String getCertHolder(){
        return this.certHolder;
    }


}
