package com.certificial.api.test.agentController;

import static org.testng.Assert.assertTrue;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.agentController.AgentRequestedProjectListResponse;
import com.certificial.api.response.agentController.AgentSharePolicyPendingRequestListResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetPendingRequestListTest extends ApiBaseTest {
	
	@Test(enabled = true)
    public void GetPendingRequestList() {

  Response response =
	givenAuth().
        contentType(ContentType.JSON).
        when().
        get(getpathURI()+ Constants.AgentPendingRequest +"/" +getAgentId()+"/"+0).
        then().
        statusCode(HttpStatus.OK.value()).
        and().extract().response();
  
  
  	Assert.assertEquals(200, response.statusCode());
  	System.out.println(response.statusCode());
  	logger.info(" GetPendingRequestList API");

  	AgentSharePolicyPendingRequestListResponse SharePolicyPendingRequestListResp = response.as(AgentSharePolicyPendingRequestListResponse.class);
  	logger.info("FromCompany: " +SharePolicyPendingRequestListResp.getData().get(0).getFromCompany().getName());
  	assertTrue(SharePolicyPendingRequestListResp.getData().get(0).getFromCompany().getName().contentEquals(getSharePolicyFromCompany()));
  	
  	logger.info("ToCompany: " +SharePolicyPendingRequestListResp.getData().get(0).getToCompany().getName());
  	assertTrue(SharePolicyPendingRequestListResp.getData().get(0).getToCompany().getName().contentEquals(getSharePolicyToCompany()));
  	
 }
}


