package com.certificial.api.test.agentController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.dashboardController.CompanyResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class IssueCOIByShareTest extends ApiBaseTest {

	@Test(enabled = true)
	public void IssueCOIByShare() {

		IssueCoiRequest postIssueCOIRequest = new IssueCoiRequest();

		postIssueCOIRequest.setUserId(getAgentId());
		postIssueCOIRequest.setProjectId(getCoiProjecId());

		postIssueCOIRequest.setSharedId(getCoiSharedId());

		Response response = givenAuth().contentType(ContentType.JSON).body(postIssueCOIRequest).when()
				.post(getpathURI() + Constants.Agent + "/client/sharepolicy/issuecoi").then()
				.statusCode(HttpStatus.OK.value()).and().extract().response();

		Assert.assertEquals(200, response.statusCode());
		System.out.println(response.statusCode());
		logger.info(" IssueCOIByShare API");

		CompanyResponse compResp = response.as(CompanyResponse.class);

		Assert.assertTrue(compResp.getData().toString().equalsIgnoreCase(Constants.COIissueMessage));

	}
}