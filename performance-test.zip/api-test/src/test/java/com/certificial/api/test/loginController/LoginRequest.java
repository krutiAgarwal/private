package com.certificial.api.test.loginController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class LoginRequest {

	
    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String user) {
        this.username = user;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
