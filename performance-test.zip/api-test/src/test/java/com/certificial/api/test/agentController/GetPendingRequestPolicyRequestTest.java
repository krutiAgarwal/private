package com.certificial.api.test.agentController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.agentController.AgentPendingRequestPolicyRequestResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetPendingRequestPolicyRequestTest extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void GetPendingRequestPolicyRequest() {

	  Response response =
		givenAuth().
               contentType(ContentType.JSON).
               when().
               get(getpathURI()+ Constants.AgentPendingRequest +"/policyrequest/"+getAgentId()+"/"+getAgentpolicyRequestId()).
               then().
               statusCode(HttpStatus.OK.value()).
               and().extract().response();
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());
	   logger.info(" GetPendingRequestPolicyRequest API");
	
	   AgentPendingRequestPolicyRequestResponse agentPendingRequestPolicyRequestResp = response.as(AgentPendingRequestPolicyRequestResponse.class);
	   logger.info(agentPendingRequestPolicyRequestResp.getData().getPolicies().get(0).getPolicyNumber());
	   Assert.assertEquals(getPolicyNumber(), agentPendingRequestPolicyRequestResp.getData().getPolicies().get(0).getPolicyNumber());
	 }
}
