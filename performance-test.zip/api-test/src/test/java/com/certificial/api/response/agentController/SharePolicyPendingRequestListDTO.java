package com.certificial.api.response.agentController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SharePolicyPendingRequestListDTO {
	
	 	private int id;
	    private SharePolicyFromCompany fromCompany;
	    private SharePolicyToCompany toCompany;
	    private String toUser;
	    private String shareTo;

	    public void setId(int id){
	        this.id = id;
	    }
	    public int getId(){
	        return this.id;
	    }
	    public void setFromCompany(SharePolicyFromCompany fromCompany){
	        this.fromCompany = fromCompany;
	    }
	    public SharePolicyFromCompany getFromCompany(){
	        return this.fromCompany;
	    }
	    public void setToCompany(SharePolicyToCompany toCompany){
	        this.toCompany = toCompany;
	    }
	    public SharePolicyToCompany getToCompany(){
	        return this.toCompany;
	    }
	    public void setToUser(String toUser){
	        this.toUser = toUser;
	    }
	    public String getToUser(){
	        return this.toUser;
	    }
	    public void setShareTo(String shareTo){
	        this.shareTo = shareTo;
	    }
	    public String getShareTo(){
	        return this.shareTo;
	    }

}
