package com.certificial.api.response.policyRequestController;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PendingRequestPoliciesResponse {
	
	private String status;
    private int code;
    private String message;
    private List<PendingRequestPoliciesDTO> data;
    private String uid;

    public PendingRequestPoliciesResponse() {
    	
    }
    
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setCode(int code){
        this.code = code;
    }
    public int getCode(){
        return this.code;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getMessage(){
        return this.message;
    }
    public void setData(List<PendingRequestPoliciesDTO> data){
        this.data = data;
    }
    public List<PendingRequestPoliciesDTO> getData(){
        return this.data;
    }
    public void setUid(String uid){
        this.uid = uid;
    }
    public String getUid(){
        return this.uid;
    }


}
