package com.certificial.api.test.dashboardController;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.testng.Assert;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.loginController.ResponseEn;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetRequesterDashboardTest extends ApiBaseTest {
	public void GetRequesterDashboard() {
		
		Response response =
				givenAuth().
	                    contentType(ContentType.JSON).
	                    when().
	                    get(getpathURI()+ Constants.Dashboard+"/"+getUserId()).
	                    then().
	                    statusCode(HttpStatus.OK.value()).
	                    and().extract().response();
	 
	 
	    Assert.assertEquals(200, response.statusCode());
	    System.out.println(response.statusCode());
	    ResponseEn responseEn = response.as(ResponseEn.class);
	    Assert.assertNotNull(responseEn.getData().getTrackedList());
	    logger.info(" GetRequesterDashboard API");
	    
	    
	  
	    
	
	}

}
