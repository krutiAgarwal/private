package com.certificial.api.test.loginController;

import static io.restassured.RestAssured.given;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.response.loginController.ResponseEn;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class AuthorizationTest extends ApiBaseTest {

	
    @Test(enabled = true)
    public void grantsAccessToken() {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(getUsername());
        loginRequest.setPassword(getPassword());
       

        Response response =
                given().
                        contentType(ContentType.JSON).
                        body(loginRequest).
                        when().
                        post(getAuthenticationURI()).
                        then().
                        statusCode(HttpStatus.OK.value()).
                        and().extract().response();

        ResponseEn responseEn = response.as(ResponseEn.class);
        System.out.println(response.statusCode());
       
        Assert.assertNotNull(responseEn.getData().getJwt());
        setCurrentToken(responseEn.getData().getJwt());
        logger.info(" Authorization API");
      
        
    }


   /* @Test
    public void grantsAccessTokenInvaildUserCredentials() {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("User");
        loginRequest.setPassword(getPassword());

        ApiError apiError =
                given().
                        contentType(ContentType.JSON).
                        body(loginRequest).
                        when().
                        post(getAuthenticationURI()).
                        then().
                        statusCode(HttpStatus.UNAUTHORIZED.value()).
                        extract().as(ApiError.class);

        Assert.assertEquals(apiError.getErrors().get(0), "Unauthorized");
        Assert.assertEquals(apiError.getMessage(), "Bad credentials");
    }*/


}
