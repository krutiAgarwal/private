package com.certificial.api.test.sharedPolicyController;

public class GetCompanyDetails2Request {
	
	private String companyId;
    private String flag;
    private String projectId;
    private String shareId;

    public void setCompanyId(String companyId){
        this.companyId = companyId;
    }
    public String getCompanyId(){
        return this.companyId;
    }
    public void setFlag(String flag){
        this.flag = flag;
    }
    public String getFlag(){
        return this.flag;
    }
    public void setProjectId(String projectId){
        this.projectId = projectId;
    }
    public String getProjectId(){
        return this.projectId;
    }
    public void setShareId(String shareId){
        this.shareId = shareId;
    }
    public String getShareId(){
        return this.shareId;
    }
}
