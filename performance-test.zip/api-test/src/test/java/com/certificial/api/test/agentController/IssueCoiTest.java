package com.certificial.api.test.agentController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.dashboardController.CompanyResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class IssueCoiTest extends ApiBaseTest {

	@Test(enabled = true)
	public void IssueCoi() {

		IssueCoiRequest postIssueCOIRequest = new IssueCoiRequest();
		postIssueCOIRequest.setPolicyIds(getPolicyIDs());
		postIssueCOIRequest.setUserId(getAgentId());

		Response response = givenAuth().contentType(ContentType.JSON).body(postIssueCOIRequest).when()
				.post(getpathURI() + Constants.Agent + "/client/issuecoi").then().statusCode(HttpStatus.OK.value())
				.and().extract().response();

		Assert.assertEquals(200, response.statusCode());
		System.out.println(response.statusCode());
		logger.info(" IssueCoi API");

		CompanyResponse compResp = response.as(CompanyResponse.class);

		Assert.assertTrue(compResp.getData().toString().equalsIgnoreCase(Constants.COIissueMessage));

	}
}