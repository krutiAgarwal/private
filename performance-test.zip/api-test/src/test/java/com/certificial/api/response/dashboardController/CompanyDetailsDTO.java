package com.certificial.api.response.dashboardController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyDetailsDTO {
	
	private int companyCount;
	private Boolean is_Visible;
	private String CompanyId;
	private String name;
	private String logo;
	private String Street;
	private String city;
	private String state;
	private String postalCode;
	private String primaryContact;
	private int count;
	
	public CompanyDetailsDTO() {
		
	}
	
	public int getCompanyCount() {
		return companyCount;
	}
	public void setCompanyCount(int companyCount) {
		this.companyCount = companyCount;
	}
	public Boolean getIs_Visible() {
		return is_Visible;
	}
	public void setIs_Visible(Boolean is_Visible) {
		this.is_Visible = is_Visible;
	}
	public String getCompanyId() {
		return CompanyId;
	}
	public void setCompanyId(String companyId) {
		CompanyId = companyId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getStreet() {
		return Street;
	}
	public void setStreet(String street) {
		Street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getPrimaryContact() {
		return primaryContact;
	}
	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	

}
