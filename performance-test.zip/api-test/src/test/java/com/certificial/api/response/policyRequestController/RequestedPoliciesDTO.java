package com.certificial.api.response.policyRequestController;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestedPoliciesDTO {
	 	private int totalPageCount;
	    private List<RequestPolicyList> requestPolicyList;

	    public void setTotalPageCount(int totalPageCount){
	        this.totalPageCount = totalPageCount;
	    }
	    public int getTotalPageCount(){
	        return this.totalPageCount;
	    }
	    public void setRequestPolicyList(List<RequestPolicyList> requestPolicyList){
	        this.requestPolicyList = requestPolicyList;
	    }
	    public List<RequestPolicyList> getRequestPolicyList(){
	        return this.requestPolicyList;
	    }
}
