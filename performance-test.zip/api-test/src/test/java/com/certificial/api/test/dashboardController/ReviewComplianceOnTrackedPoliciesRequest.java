package com.certificial.api.test.dashboardController;

public class ReviewComplianceOnTrackedPoliciesRequest {
	
	private String projectId;
	private String shareId;
	private Boolean isReviewed;
	
	
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getShareId() {
		return shareId;
	}
	public void setShareId(String shareId) {
		this.shareId = shareId;
	}
	public Boolean getIsReviewed() {
		return isReviewed;
	}
	public void setIsReviewed(Boolean isReviewed) {
		this.isReviewed = isReviewed;
	}

	
}
