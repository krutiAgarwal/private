package com.certificial.api.test.agentController;

import static org.testng.Assert.assertTrue;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.agentController.AgentRequestedProjectListResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetRequestedProjectsListTest extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void GetRequestedProjectsList() {

	  Response response =
		givenAuth().
            contentType(ContentType.JSON).
            when().
            get(getpathURI()+ Constants.Agent+"/requesterproject/"+getAgentId() +"/"+getRequesterCompanyId()+"/"+getInsuredCompanyId()).
            then().
            statusCode(HttpStatus.OK.value()).
            and().extract().response();
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());
	   logger.info(" GetRequestedProjectsList");
	
	   AgentRequestedProjectListResponse agentRequestedProjectListResponse = response.as(AgentRequestedProjectListResponse.class);
	   logger.info(agentRequestedProjectListResponse.getData().get(0).getName());
	   assertTrue(agentRequestedProjectListResponse.getData().get(0).getName().contentEquals(getRequestedProject()));
 
	 }
}