package com.certificial.api.response.policyRequestController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PendingRequestDetails {
	
	private int requestId;
    private int projectId;
    private String projectName;
    private String requiredRating;
    private String instructionText;
    private String templateId;
    private int regionId;
    private String regionName;
    private String regionCurrency;
    private String currencySymbol;

    public void setRequestId(int requestId){
        this.requestId = requestId;
    }
    public int getRequestId(){
        return this.requestId;
    }
    public void setProjectId(int projectId){
        this.projectId = projectId;
    }
    public int getProjectId(){
        return this.projectId;
    }
    public void setProjectName(String projectName){
        this.projectName = projectName;
    }
    public String getProjectName(){
        return this.projectName;
    }
    public void setRequiredRating(String requiredRating){
        this.requiredRating = requiredRating;
    }
    public String getRequiredRating(){
        return this.requiredRating;
    }
    public void setInstructionText(String instructionText){
        this.instructionText = instructionText;
    }
    public String getInstructionText(){
        return this.instructionText;
    }
    public void setTemplateId(String templateId){
        this.templateId = templateId;
    }
    public String getTemplateId(){
        return this.templateId;
    }
    public void setRegionId(int regionId){
        this.regionId = regionId;
    }
    public int getRegionId(){
        return this.regionId;
    }
    public void setRegionName(String regionName){
        this.regionName = regionName;
    }
    public String getRegionName(){
        return this.regionName;
    }
    public void setRegionCurrency(String regionCurrency){
        this.regionCurrency = regionCurrency;
    }
    public String getRegionCurrency(){
        return this.regionCurrency;
    }
    public void setCurrencySymbol(String currencySymbol){
        this.currencySymbol = currencySymbol;
    }
    public String getCurrencySymbol(){
        return this.currencySymbol;
    }


}
