package com.certificial.api.response.dashboardController;

import java.util.List;

import com.certificial.api.response.policyRequestController.PoliciesDetailsDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyDetails {
	
	List<PoliciesDetailsDTO> policies_data;

	public List<PoliciesDetailsDTO> getPolicies_data() {
		return policies_data;
	}

	public void setPolicies_data(List<PoliciesDetailsDTO> policies_data) {
		this.policies_data = policies_data;
	}
}
