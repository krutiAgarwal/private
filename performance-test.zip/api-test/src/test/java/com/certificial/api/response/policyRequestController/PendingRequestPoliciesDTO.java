package com.certificial.api.response.policyRequestController;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PendingRequestPoliciesDTO {

	
	private CertHolder certHolder;
private List<PoliciesDetailsDTO> policies;

public List<PoliciesDetailsDTO> getPolicies() {
	return policies;
}

public void setPolicies(List<PoliciesDetailsDTO> policies) {
	this.policies = policies;
}



	public CertHolder getCertHolder() {
		return certHolder;
	}

	public void setCertHolder(CertHolder certHolder) {
		this.certHolder = certHolder;
	}


	

	
	
	

    
}
