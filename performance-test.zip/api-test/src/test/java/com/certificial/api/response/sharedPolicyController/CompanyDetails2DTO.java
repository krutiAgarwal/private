package com.certificial.api.response.sharedPolicyController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyDetails2DTO {

    private int id;
    private String name;
    private String shareId;
    private String projectId;
    private String flag;
    private int primaryContactId;
    private String userName;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String logo;
    private boolean isVisible;
    private int insuredUserId;

    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setShareId(String shareId){
        this.shareId = shareId;
    }
    public String getShareId(){
        return this.shareId;
    }
    public void setProjectId(String projectId){
        this.projectId = projectId;
    }
    public String getProjectId(){
        return this.projectId;
    }
    public void setFlag(String flag){
        this.flag = flag;
    }
    public String getFlag(){
        return this.flag;
    }
    public void setPrimaryContactId(int primaryContactId){
        this.primaryContactId = primaryContactId;
    }
    public int getPrimaryContactId(){
        return this.primaryContactId;
    }
    public void setUserName(String userName){
        this.userName = userName;
    }
    public String getUserName(){
        return this.userName;
    }
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    public String getFirstName(){
        return this.firstName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public String getLastName(){
        return this.lastName;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }
    public void setPhone(String phone){
        this.phone = phone;
    }
    public String getPhone(){
        return this.phone;
    }
    public void setLogo(String logo){
        this.logo = logo;
    }
    public String getLogo(){
        return this.logo;
    }
    public void setIsVisible(boolean isVisible){
        this.isVisible = isVisible;
    }
    public boolean getIsVisible(){
        return this.isVisible;
    }
    public void setInsuredUserId(int insuredUserId){
        this.insuredUserId = insuredUserId;
    }
    public int getInsuredUserId(){
        return this.insuredUserId;
    }
}
