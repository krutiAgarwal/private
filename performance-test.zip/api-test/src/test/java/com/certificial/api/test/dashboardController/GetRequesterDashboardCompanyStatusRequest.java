package com.certificial.api.test.dashboardController;

public class GetRequesterDashboardCompanyStatusRequest {
	
	private String companyId ;
	private String projectId; 
	private String sharedId;
	private int userId ;
	private String polId;
	private String requestId;
	private String statusFilter;
	
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getSharedId() {
		return sharedId;
	}
	public void setSharedId(String sharedId) {
		this.sharedId = sharedId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPolId() {
		return polId;
	}
	public void setPolId(String polId) {
		this.polId = polId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getStatusFilter() {
		return statusFilter;
	}
	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}
	
	
}
