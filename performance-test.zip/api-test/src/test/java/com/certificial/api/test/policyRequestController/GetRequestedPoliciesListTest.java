package com.certificial.api.test.policyRequestController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.policyRequestController.RequestedPoliciesListResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetRequestedPoliciesListTest extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void GetRequestedPoliciesList() {

	
	  Response response =
		givenAuth().
             contentType(ContentType.JSON).
             when().
             get(getpathURI()+ Constants.PolicyRequest +"/"+getUserId()).
             then().
             statusCode(HttpStatus.OK.value()).
             and().extract().response();
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());
	   logger.info(" GetRequestedPoliciesList API");
	   
	   RequestedPoliciesListResponse requestedPoliciesListResponse = response.as(RequestedPoliciesListResponse.class);	
	   logger.info(requestedPoliciesListResponse.getData().getRequestPolicyList().get(0).getStatus());
	   Assert.assertTrue(requestedPoliciesListResponse.getData().getRequestPolicyList().get(0).getStatus().contentEquals(getRequestPolicyStatus().toString()));
	 }
}
