package com.certificial.api.test.policyRequestController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.policyRequestController.PendingRequestPoliciesResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetAllPendingRequestPoliciesTest extends ApiBaseTest {

	@Test(enabled = true)
	public void GetAllPendingRequestPolicies() {

		Response response = givenAuth().contentType(ContentType.JSON).when()
				.get(getpathURI() + Constants.PolicyRequest +"/pendinglist/policies/" + getCompanyId() + "/" + getRequestID())
				.then().statusCode(HttpStatus.OK.value()).and().extract().response();

		Assert.assertEquals(200, response.statusCode());
		System.out.println(response.statusCode());
		logger.info(" GetAllPending Request Policies API");

		//System.out.println(response.asString());

		PendingRequestPoliciesResponse pendingRequestPoliciesResponse = response
				.as(PendingRequestPoliciesResponse.class);
		logger.info(pendingRequestPoliciesResponse.getData().get(0).getCertHolder().getName());
		Assert.assertTrue(pendingRequestPoliciesResponse.getData().get(0).getCertHolder().getName()
				.contentEquals(getCompanies()));
		String[] temp = getPendingRequestedPolicies().split(",");

		for (int i = 0; i < temp.length; i++) {

			logger.info(pendingRequestPoliciesResponse.getData().get(0).getPolicies().get(i).getPolicytype());

			Assert.assertTrue(pendingRequestPoliciesResponse.getData().get(0).getPolicies().get(i).getPolicytype()
					.equalsIgnoreCase(temp[i]));

		}

	}
}
