package com.certificial.api.response.policyRequestController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestedPolicyTypesResponse {

	private String status;
    private int code;
    private String message;
    private PolicyTypesRequestDetailsDTO data;
    private String uid;
    
    
    RequestedPolicyTypesResponse(){
		
	}

    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setCode(int code){
        this.code = code;
    }
    public int getCode(){
        return this.code;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getMessage(){
        return this.message;
    }
    public void setData(PolicyTypesRequestDetailsDTO data){
        this.data = data;
    }
    public PolicyTypesRequestDetailsDTO getData(){
        return this.data;
    }
    public void setUid(String uid){
        this.uid = uid;
    }
    public String getUid(){
        return this.uid;
    }
	
}
