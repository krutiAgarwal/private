package com.certificial.api.test.userController;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.io.Serializable;
import java.sql.Timestamp;


@JsonInclude(value = Include.NON_NULL)
public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public User(long id) {
		super();
		this.id = id;
	}
	
	public User(String email) {
		super();
		this.email = email;
	}


	private Long id;
	
	private String password;
	
	private Timestamp lastLogin;
	
	private Boolean isSuperuser;
	
	private String username;
	
	private String firstName;
	
	private String lastName;
	
	private String email;
	
	private Boolean isStaff;
	
	private Boolean isActive;
	
	private Timestamp dateJoined;

	private Timestamp created;

	private Timestamp modified;

	private String address1;

	private String address2;

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Timestamp getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Timestamp lastLogin) {
		this.lastLogin = lastLogin;
	}

	public Boolean getSuperuser() {
		return isSuperuser;
	}

	public void setSuperuser(Boolean superuser) {
		isSuperuser = superuser;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Boolean getStaff() {
		return isStaff;
	}

	public void setStaff(Boolean staff) {
		isStaff = staff;
	}

	public Boolean getActive() {
		return isActive;
	}

	public void setActive(Boolean active) {
		isActive = active;
	}

	public Timestamp getDateJoined() {
		return dateJoined;
	}

	public void setDateJoined(Timestamp dateJoined) {
		this.dateJoined = dateJoined;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public Timestamp getModified() {
		return modified;
	}

	public void setModified(Timestamp modified) {
		this.modified = modified;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public boolean getCustomer() {
		return false;
	}

	public boolean getCompany() {
		return false;
	}
}
