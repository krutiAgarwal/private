package com.certificial.api.test.sharedPolicyController;

public class GetAllProjectDetailsRequest {
	private String companyId;
	private String sharedCompanyId;
	private String sharedUserId;
	
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getSharedCompanyId() {
		return sharedCompanyId;
	}
	public void setSharedCompanyId(String sharedCompanyId) {
		this.sharedCompanyId = sharedCompanyId;
	}
	public String getSharedUserId() {
		return sharedUserId;
	}
	public void setSharedUserId(String sharedUserId) {
		this.sharedUserId = sharedUserId;
	}
	
	

}
