package com.certificial.api.test.agentController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.agentController.AgentOpenRequestResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetAgentsOpenRequestCountTest extends ApiBaseTest {
	
	@Test(enabled = true)
    public   void  GetAgentsOpenRequestCount() {

  Response response =
		givenAuth().
               contentType(ContentType.JSON).
               when().
               get(getpathURI()+Constants.AgentOpenrequest+"/count/"+getAgentId()).
               then().
               statusCode(HttpStatus.OK.value()).
               and().extract().response();
  
  	//System.out.println(response.asString());
  
  	Assert.assertEquals(200, response.statusCode());
  	System.out.println(response.statusCode());
   
  	logger.info(" Get count of total number of Pending requests on Agents Open Request tab API");
   
  	AgentOpenRequestResponse agentOpenRequestResponse = response.as(AgentOpenRequestResponse.class);
	logger.info(agentOpenRequestResponse.getData());	
	Assert.assertTrue(agentOpenRequestResponse.getData().contentEquals(getAgentOpenRequestCount()));


  	
	}
}
