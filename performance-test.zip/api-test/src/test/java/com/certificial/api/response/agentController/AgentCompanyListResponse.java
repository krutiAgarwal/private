package com.certificial.api.response.agentController;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentCompanyListResponse {
	  	private String status;
	    private int code;
	    private String message;
	    private List<AgentCompanyData> data;
	    private String uid;

	    
	    public AgentCompanyListResponse() {
	    	
	    }
	    
	    public void setStatus(String status){
	        this.status = status;
	    }
	    public String getStatus(){
	        return this.status;
	    }
	    public void setCode(int code){
	        this.code = code;
	    }
	    public int getCode(){
	        return this.code;
	    }
	    public void setMessage(String message){
	        this.message = message;
	    }
	    public String getMessage(){
	        return this.message;
	    }
	    public void setData(List<AgentCompanyData> data){
	        this.data = data;
	    }
	    public List<AgentCompanyData> getData(){
	        return this.data;
	    }
	    public void setUid(String uid){
	        this.uid = uid;
	    }
	    public String getUid(){
	        return this.uid;
	    }

}
