package com.certificial.api.response.policyRequestController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyRequestDetailsDTO {
	
	 	private int id;
	    private Boolean agentApprovalRequired;

	    public void setId(int id){
	        this.id = id;
	    }
	    public int getId(){
	        return this.id;
	    }
	    public void setAgentApprovalRequired(Boolean agentApprovalRequired){
	        this.agentApprovalRequired = agentApprovalRequired;
	    }
	    public Boolean getAgentApprovalRequired(){
	        return this.agentApprovalRequired;
	    }

}
