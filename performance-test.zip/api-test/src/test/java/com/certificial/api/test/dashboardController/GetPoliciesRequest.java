package com.certificial.api.test.dashboardController;

import java.util.List;
import java.util.ArrayList;


public class GetPoliciesRequest {
	
	
	private String companyId ;
	private String projectId; 
	private String userId ;
	private List<Integer> daysExpiredFilter;
	private List<Integer> endorsementFilter;
	private List<Integer> statusFilter;

	
	
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<Integer> getDaysExpiredFilter() {
		return daysExpiredFilter;
	}
	public void setDaysExpiredFilter(List<Integer> daysExpiredFilter) {
		this.daysExpiredFilter = daysExpiredFilter;
	}
	public List<Integer> getEndorsementFilter() {
		return endorsementFilter;
	}
	public void setEndorsementFilter(List<Integer> endorsementFilter) {
		this.endorsementFilter = endorsementFilter;
	}
	public List<Integer> getStatusFilter() {
		return statusFilter;
	}
	public void setStatusFilter(List<Integer> statusFilter) {
		this.statusFilter = statusFilter;
	}
	
	

}
