package com.certificial.api.test.dashboardController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.dashboardController.CompanyResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class ReviewComplianceOnTrackedPoliciesTest extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void ReviewComplianceOnTrackedPolicies() {
	       
		 ReviewComplianceOnTrackedPoliciesRequest compRevRequest= new ReviewComplianceOnTrackedPoliciesRequest();
		 compRevRequest.setProjectId(getProjectId());
		 compRevRequest.setShareId(getSharedId());
		 compRevRequest.setIsReviewed(getIsReviewed());
		 
	        Response response =
	        		givenAuth().
	                        contentType(ContentType.JSON).
	                        body(compRevRequest).
	                        when().
	                        post(getpathURI()+Constants.Dashboard+"/compliance/review").
	                        then().
	                        statusCode(HttpStatus.OK.value()).
	                        and().extract().response();

	        Assert.assertEquals(200, response.statusCode());
	        System.out.println(response.statusCode());
	        logger.info(" ReviewComplianceOnTrackedPolicies API");

	       CompanyResponse compResp = response.as(CompanyResponse.class);
	       logger.info(compResp.getData().toString());
	       Assert.assertEquals(Constants.reviewComplianceStatus, compResp.getData().toString());
	    
	        
}
}