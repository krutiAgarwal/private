package com.certificial.api.response.policyRequestController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestedPoliciesListResponse {
	
	  	private String status;
	    private int code;
	    private String message;
	    private RequestedPoliciesDTO data;
	    private String uid;
	    
	    public RequestedPoliciesListResponse() {
	    	
	    }

	    public void setStatus(String status){
	        this.status = status;
	    }
	    public String getStatus(){
	        return this.status;
	    }
	    public void setCode(int code){
	        this.code = code;
	    }
	    public int getCode(){
	        return this.code;
	    }
	    public void setMessage(String message){
	        this.message = message;
	    }
	    public String getMessage(){
	        return this.message;
	    }
	    public void setData(RequestedPoliciesDTO data){
	        this.data = data;
	    }
	    public RequestedPoliciesDTO getData(){
	        return this.data;
	    }
	    public void setUid(String uid){
	        this.uid = uid;
	    }
	    public String getUid(){
	        return this.uid;
	    }

}
