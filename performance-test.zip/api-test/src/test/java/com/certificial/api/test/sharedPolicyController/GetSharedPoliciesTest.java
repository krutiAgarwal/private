package com.certificial.api.test.sharedPolicyController;

import org.springframework.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.certificial.api.config.ApiBaseTest;
import com.certificial.api.config.Constants;
import com.certificial.api.response.sharedPolicyController.SharedPoliciesResponse;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GetSharedPoliciesTest extends ApiBaseTest {
	
	 @Test(enabled = true)
	    public void GetSharedPolicies() {
	
	  Response response =
  		givenAuth().
                  contentType(ContentType.JSON).
                  when().
                  get(getpathURI()+Constants.SharedPolicy+"/list/"+getCompanyId()).
                  then().
                  statusCode(HttpStatus.OK.value()).
                  and().extract().response();
	  
	   Assert.assertEquals(200, response.statusCode());
	   System.out.println(response.statusCode());
	   logger.info(" GetSharedPolicies API");
	
	   //System.out.println(response.asString());
	   SharedPoliciesResponse sharedPoliciesResponse = response.as(SharedPoliciesResponse.class);
	   
	   String[] temp = getSharedPolicies().split(","); 	
		  for (int i = 0; i < temp.length; i++) {
		  
			  logger.info(sharedPoliciesResponse.getData().getChildren().get(i). getName());
			  Assert.assertTrue(sharedPoliciesResponse.getData().getChildren().get(i). getName().contentEquals(temp[i]));

		  }
		 
	 }
}