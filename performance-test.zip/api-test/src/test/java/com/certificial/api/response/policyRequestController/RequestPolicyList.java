package com.certificial.api.response.policyRequestController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestPolicyList {
	private String insuredUserId;
    private InsuredCompanyDetails insuredCompanyId;
    private String status;
    private String lastUpdatedOn;

    public void setInsuredUserId(String insuredUserId){
        this.insuredUserId = insuredUserId;
    }
    public String getInsuredUserId(){
        return this.insuredUserId;
    }
    public void setInsuredCompanyId(InsuredCompanyDetails insuredCompanyId){
        this.insuredCompanyId = insuredCompanyId;
    }
    public InsuredCompanyDetails getInsuredCompanyId(){
        return this.insuredCompanyId;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setLastUpdatedOn(String lastUpdatedOn){
        this.lastUpdatedOn = lastUpdatedOn;
    }
    public String getLastUpdatedOn(){
        return this.lastUpdatedOn;
    }

}
