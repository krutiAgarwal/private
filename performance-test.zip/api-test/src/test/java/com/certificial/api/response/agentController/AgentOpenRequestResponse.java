package com.certificial.api.response.agentController;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentOpenRequestResponse {
	private String status;
    private int code;
    private String message;
    private String data;
    private String uid;

    public AgentOpenRequestResponse() {
    	
    }
    
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
    public void setCode(int code){
        this.code = code;
    }
    public int getCode(){
        return this.code;
    }
    public void setMessage(String message){
        this.message = message;
    }
    public String getMessage(){
        return this.message;
    }
	
    public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setUid(String uid){
        this.uid = uid;
    }
    public String getUid(){
        return this.uid;
    }

	

}
