package com.certificial.api.config;

public class Constants {
	
	public static final String Dashboard = "/dashboard";
	public static final String PolicyRequest = "/policy/request";
	public static final String SharedPolicy = "/sharedpolicy";
	public static final String Agent = "/agent";
	public static final String AgentDashboard= "/agent/dashboard";
	public static final String AgentClients = "/agent/clients";
	public static final String AgentOpenrequest = "/agent/openrequest";
	public static final String AgentPendingRequest = "/agent/pendingrequest";
	public static final String User = "/user";
	public static final String Logout = "/logout";
	public static final String Maintenance = "/maintenance";
	
	public static final String COIissueMessage="COI issued to requestor successfully.";	
	public static final String reviewComplianceStatus ="Compliance status updated successfully.";
	
}
