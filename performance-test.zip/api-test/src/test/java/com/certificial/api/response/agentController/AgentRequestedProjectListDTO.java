package com.certificial.api.response.agentController;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentRequestedProjectListDTO {
	
	    private int id;
	    private String name;
	    private String shareId;
	    private int requestId;
	    private String flag;
	    private String regionCurrency;
	    private String regionId;
	    private String regionName;
	    private String tempalteId;
	    //private boolean default;

	    public void setId(int id){
	        this.id = id;
	    }
	    public int getId(){
	        return this.id;
	    }
	    public void setName(String name){
	        this.name = name;
	    }
	    public String getName(){
	        return this.name;
	    }
	    public void setShareId(String shareId){
	        this.shareId = shareId;
	    }
	    public String getShareId(){
	        return this.shareId;
	    }
	    public void setRequestId(int requestId){
	        this.requestId = requestId;
	    }
	    public int getRequestId(){
	        return this.requestId;
	    }
	    public void setFlag(String flag){
	        this.flag = flag;
	    }
	    public String getFlag(){
	        return this.flag;
	    }
	    public void setRegionCurrency(String regionCurrency){
	        this.regionCurrency = regionCurrency;
	    }
	    public String getRegionCurrency(){
	        return this.regionCurrency;
	    }
	    public void setRegionId(String regionId){
	        this.regionId = regionId;
	    }
	    public String getRegionId(){
	        return this.regionId;
	    }
	    public void setRegionName(String regionName){
	        this.regionName = regionName;
	    }
	    public String getRegionName(){
	        return this.regionName;
	    }
	    public void setTempalteId(String tempalteId){
	        this.tempalteId = tempalteId;
	    }
	    public String getTempalteId(){
	        return this.tempalteId;
	    }
		/*
		 * public void setDefault(boolean default){ this.default = default; } public
		 * boolean getDefault(){ return this.default; }
		 */

}
