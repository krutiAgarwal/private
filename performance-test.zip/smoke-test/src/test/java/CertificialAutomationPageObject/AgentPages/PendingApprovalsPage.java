package CertificialAutomationPageObject.AgentPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PendingApprovalsPage {
public  WebDriver driver;
	
	public  PendingApprovalsPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(xpath="//h4[contains(.,'Pending Approvals')]")
	private WebElement pendingApprovalsHeader;
	public WebElement getPendingApprovalsHeader()
	{
		return pendingApprovalsHeader;
	}
}
