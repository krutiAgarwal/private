package com.todos.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.todos.qa.testcases.HomePageTest;

public class HomePage extends HomePageTest {

	@FindBy(xpath = "//h1")
	WebElement todosLogo;

	@FindBy(xpath = "//input[@class='new-todo']")
	WebElement todosTextBox;

	@FindBy(xpath = "//label[contains(text(),'Test1')]//ancestor::li//input[1]")

	WebElement checkBoxToComplete;

	@FindBy(xpath = "//label[contains(text(),'Test1')]")
	WebElement taskCreated;

	public WebElement getCheckBoxToComplete() {
		return checkBoxToComplete;
	}

	public WebElement getTaskCreated() {
		return taskCreated;
	}

	public WebElement getTodosTextBox() {
		return todosTextBox;
	}

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	public String validatetodosHeading() {

		return todosLogo.getText();
	}

	public String createTask(String name) {

		todosTextBox.click();
		todosTextBox.sendKeys(name);
		todosTextBox.sendKeys(Keys.ENTER);

		return taskCreated.getText();

	}

}
