package practise;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class testq {
	

   @BeforeSuite
 public void testing() {
	   
	   System.out.println("I will run the Before Suite ");
	 
	 
	 
 }
   
   @BeforeTest
   
   public void test() {
	   
	   System.out.println("I will run the Before test ");
	   
   }
   
   
   @BeforeMethod
   
   public void method() {
	   System.out.println("I will run the Before method ");
	   
	   
   }
   
   @Test
   
   public void test2() {
   
  
   
   }
   
  @Test
   
   public void test3() {
   
  
   
   }
  
  
  @Test
  
  public void test4() {
  
 
  
  }
   
 @BeforeClass
   
   public void tes1t() {
	   
	   System.out.println("I will run the Before class ");
	   
   }
 
public static void main(String args[]) {
	
	int i,fact=1;  
	  int number=5;//It is the number to calculate factorial    
	  for(i=1;i<=number;i++){    
	      fact=fact*i;    
	  }    
	  System.out.println("Factorial of "+number+" is: "+fact);    
	 }  
	}  
	





