package practise;

public class parentCLass {
	
	
	
	parentCLass(){
		
		super();
		
		System.out.println("I am the constructor of Parent class");
		
	}
	
	
	public void parent() {
		
		
		System.out.println("I am a parent class ");
	}
	
	
	public void overridenMethod() {
		
		
		System.out.println("I am a parent class oveeriden method ");
	}

}
