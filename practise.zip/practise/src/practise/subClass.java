package practise;

public class subClass extends superClass{



	
	public static void main () {
		
		System.out.println("Just checking");
		
	}
	
	 static public void main (String args[]) {
		
		
		String Str="k1:Va11,K2:Val2,K3:Val3";
		String S3=null;
		
		int j=0;
		
		String[] S1=Str.split(",");
		
		
		
		
		for(int i=0;i<S1.length;i++) {
			
			
			String[] S2=S1[i].split(":");
			
			
				
			S3="\""+S2[j]+"\"" + ":" + "\"" + S2[j+1] + "\""; 
			
			
			System.out.print(S3);
			
				
			}
			
			
				
				
				
			}
			
			
			
			
			
			
					
		}
		
		
		
	
	


