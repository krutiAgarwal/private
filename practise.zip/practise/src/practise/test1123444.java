package practise;

public class test1123444 {
	
	
	public static void main (String args[]) {
		String S="Kruti Agarwal";


				int count [] =new int[256];
				int find =0;

				char ch[] =new char[S.length()];

				for(int i=0; i<S.length();i++){

				ch[i]=S.charAt(i);

				for (int j=0;j<=i;j++){

				//if match yes 

				if(S.charAt(i)==ch[j]){

				find ++;

				}
				}
			
				if( find==1){

				System.out.println("Occurences"+S.charAt(i)+ "is"+ count[S.charAt(i)]);

				}}
	}


}