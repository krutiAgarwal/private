package practise;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class reverseWordinString {

	
	
	public static void main (String args[]) {
		
		
		
		String S="Kruti is a Pagal ";
		
		String [] Sw=S.split(" ");
		
		List<String> d=new ArrayList<String>();
		
		for (int i=0; i<Sw.length;i++) {
			
			
			d.get(i);
					
			
		}
		

//		Collections.reverse(d);
//		
//		
//		for (int j=0;j<d.size();j++) {
//			
//			System.out.println("The reverse string is" +d.get(j));
//			
			
			
		}
		
		
	}
	

