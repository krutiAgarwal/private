package practise;

public class ChildCLass extends parentCLass {
	
	
	
	ChildCLass(){
		
		super();
		System.out.println("I am the Constructor Of child class");
	}
	

	public void child() {
		
		

		System.out.println("I am child class ");

	}

	public void overridenMethod() {
		
//this.child();//with the help of this keyword we can call the Child class method by creating the reference of parent class 
		System.out.println("I am a oveeriden method of child class");
	}

	public static void main(String args[]) {

		ChildCLass CL=new ChildCLass();
		
		
		
		parentCLass PC = new ChildCLass();// When the Reference of parent class creates it wont be called the methods of
											// child class only overriden method will be called

		PC.parent();

		PC.overridenMethod();// Parent class overriden method with its implementation of Child class
								// Overriden method
//
//		ChildCLass CL = new ChildCLass();
//		CL.child();
//		CL.overridenMethod();
//
//		parentCLass PC1 = new parentCLass();
//
//		PC1.overridenMethod();
//		// Cannot create the Reference of child class to create an object of parent
//		// class Complie time error comes
//		ChildCLass CL1=(ChildCLass) new parentCLass();

		
		
	}

}
