package practise;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class duplicateCharactersInString {

	static int a;
	final int b = 10;

	public void duplicateCharacters(String Str) {

		Map<String, Integer> map = new HashMap<String, Integer>();
		
		
	

//		Map<Character, Integer> map = new HashMap<Character, Integer>();

//		char[] ch = Str.toCharArray();
		String[] S1 = Str.split(" ");

//		for(Character C:S1)

		for (String c : S1) {

			if (map.containsKey(c)) {

				map.put(c, map.get(c) + 1);

			}

			else {

				map.put(c, 1);
			}

		}

		for (Map.Entry<String, Integer> entry : map.entrySet()) {

			if (entry.getValue() > 1) {

				System.out.println(entry.getKey() + ": " + entry.getValue());

			}

		}

	}

	public static void main(String[] args) {
		duplicateCharactersInString db = new duplicateCharactersInString();

		db.duplicateCharacters("my name is Kruti Kruti is my name");

	}

}
