package practise;

public class testNG extends testq {
	
	
	




public static void main (String args[]) {
	
//	
//	String S1=new String ("abc");
//	
//	String S2="abc";
//	
//	String S3="abc";
//	
//	System.out.println(S1==S2);
//	System.out.println(S1.compareTo(S3));
	
	
	//s1 == s2 :0
//	s1 > s2   :positive value
//	s1 < s2   :negative value
	
	
	
	
	 String src= "my name is kruti";

     char[] srcChar= src.toLowerCase().toCharArray();

     int len=srcChar.length;
     int j=0;
     boolean flag=false;
     char ch;

     //      System.out.println("Length of the String is "+len1);
     //      System.out.println("Length of the character array is "+len);


     int k=0;

     for(int i=0;i<len;i++)
     {
         //          System.out.println("i-----> "+i + " and character is "+srcChar[i]);
         for(j=0;j<len;j++)
         {
             //              System.out.println("j-----> "+j + " and character is "+srcChar[j]);
             if(srcChar[i]==srcChar[j])
             {
                 k++;
             }
         }
         if(k>1)
         {
             if(srcChar[i]>1)
             {
                 System.out.println("This character "+srcChar[i]+" has repeated "+k+ " time");
             }
             else
             {
                 System.out.println("There are no characters repeated in the given string");
             }
         }
         k=0;
     }
 }
}
			