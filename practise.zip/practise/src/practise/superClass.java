package practise;


public class superClass {


	
}
